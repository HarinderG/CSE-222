#define LISTSIZE 100
#define MYNULL -1

typedef struct{
		int data;
		int next;
		int valid;
	}node;